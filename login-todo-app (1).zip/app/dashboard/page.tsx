"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import TodoList from "@/components/todo-list"
import { Button } from "@/components/ui/button"

export default function Dashboard() {
  const [user, setUser] = useState<{ email: string } | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/")
      return
    }

    setUser(JSON.parse(userData))
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  if (!user) {
    return null // Will redirect in useEffect
  }

  return (
    <main className="flex min-h-screen flex-col items-center p-4 bg-gradient-to-b from-blue-400 to-blue-600">
      <div className="w-full max-w-4xl">
        <div className="flex justify-between items-center mb-8 bg-white/10 backdrop-blur-sm p-4 rounded-lg">
          <div>
            <h1 className="text-3xl font-bold text-white">Your Todo List</h1>
            <p className="text-blue-50">Welcome back, {user.email}</p>
          </div>
          <Button
            variant="outline"
            onClick={handleLogout}
            className="border-blue-300 bg-white/20 text-white hover:bg-blue-700"
          >
            Logout
          </Button>
        </div>

        <TodoList />
      </div>
    </main>
  )
}
