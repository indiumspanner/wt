import LoginForm from "@/components/login-form"
import FloatingTodoList from "@/components/floating-todo-list"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col lg:flex-row overflow-hidden relative">
      {/* Water background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-400 to-blue-600 overflow-hidden">
        <div className="water-waves"></div>
      </div>

      {/* Login section (left side) */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 z-10">
        <div className="w-full max-w-md">
          <div className="text-center lg:text-left mb-8">
            <h1 className="text-3xl font-bold text-white drop-shadow-md">Welcome Back</h1>
            <p className="text-blue-50 mt-2">Sign in to access your tasks</p>
          </div>
          <LoginForm />
        </div>
      </div>

      {/* Animated floating to-do list (right side) */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 z-10">
        <FloatingTodoList />
      </div>
    </main>
  )
}
