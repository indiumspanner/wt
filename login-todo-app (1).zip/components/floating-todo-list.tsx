"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"

interface TodoItem {
  id: number
  text: string
  completed: boolean
}

export default function FloatingTodoList() {
  const [todos, setTodos] = useState<TodoItem[]>([
    { id: 1, text: "Complete project proposal", completed: true },
    { id: 2, text: "Schedule team meeting", completed: false },
    { id: 3, text: "Research new technologies", completed: false },
    { id: 4, text: "Update portfolio website", completed: true },
    { id: 5, text: "Review client feedback", completed: false },
  ])

  // Simulate random completion of tasks for animation
  useEffect(() => {
    const interval = setInterval(() => {
      setTodos((prevTodos) =>
        prevTodos.map((todo) => ({
          ...todo,
          completed: Math.random() > 0.7 ? !todo.completed : todo.completed,
        })),
      )
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative w-full max-w-md">
      {/* Main floating card */}
      <Card className="w-full border-blue-200 shadow-xl backdrop-blur-sm bg-white/90 animate-float">
        <CardHeader className="bg-blue-600 text-white rounded-t-lg">
          <h2 className="text-xl font-semibold">Your Tasks</h2>
        </CardHeader>
        <CardContent className="bg-white/90 p-4">
          <ul className="space-y-3">
            {todos.map((todo) => (
              <li
                key={todo.id}
                className="flex items-center p-3 border border-blue-100 rounded-md hover:bg-blue-50 transition-all"
              >
                <Checkbox
                  id={`todo-${todo.id}`}
                  checked={todo.completed}
                  className="border-blue-400 text-blue-600 mr-3"
                />
                <label
                  htmlFor={`todo-${todo.id}`}
                  className={`cursor-pointer ${todo.completed ? "line-through text-blue-300" : "text-blue-800"}`}
                >
                  {todo.text}
                </label>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Decorative floating bubbles */}
      <div className="bubble bubble-1"></div>
      <div className="bubble bubble-2"></div>
      <div className="bubble bubble-3"></div>
      <div className="bubble bubble-4"></div>
    </div>
  )
}
