"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"

interface Todo {
  id: string
  text: string
  completed: boolean
}

export default function TodoList() {
  const [todos, setTodos] = useState<Todo[]>([])
  const [newTodo, setNewTodo] = useState("")
  const { toast } = useToast()

  // Load todos from localStorage on component mount
  useEffect(() => {
    const savedTodos = localStorage.getItem("todos")
    if (savedTodos) {
      setTodos(JSON.parse(savedTodos))
    }
  }, [])

  // Save todos to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos))
  }, [todos])

  const addTodo = (e: React.FormEvent) => {
    e.preventDefault()

    if (!newTodo.trim()) return

    const todo: Todo = {
      id: Date.now().toString(),
      text: newTodo.trim(),
      completed: false,
    }

    setTodos([...todos, todo])
    setNewTodo("")

    toast({
      title: "Todo added",
      description: "Your new task has been added to the list",
    })
  }

  const toggleTodo = (id: string) => {
    setTodos(todos.map((todo) => (todo.id === id ? { ...todo, completed: !todo.completed } : todo)))
  }

  const deleteTodo = (id: string) => {
    setTodos(todos.filter((todo) => todo.id !== id))

    toast({
      title: "Todo removed",
      description: "The task has been removed from your list",
    })
  }

  return (
    <Card className="w-full border-blue-200 shadow-lg backdrop-blur-sm bg-white/90">
      <CardHeader className="bg-blue-600 text-white rounded-t-lg">
        <form onSubmit={addTodo} className="flex gap-2">
          <Input
            type="text"
            placeholder="Add a new task..."
            value={newTodo}
            onChange={(e) => setNewTodo(e.target.value)}
            className="flex-1 border-blue-300 bg-white text-blue-900"
          />
          <Button type="submit" className="bg-blue-700 hover:bg-blue-800 text-white">
            Add
          </Button>
        </form>
      </CardHeader>
      <CardContent className="bg-white/90">
        {todos.length === 0 ? (
          <p className="text-center text-blue-500 py-4">You don't have any tasks yet. Add one above!</p>
        ) : (
          <ul className="space-y-3">
            {todos.map((todo) => (
              <li
                key={todo.id}
                className="flex items-center justify-between p-3 border border-blue-100 rounded-md hover:bg-blue-50"
              >
                <div className="flex items-center gap-3">
                  <Checkbox
                    id={`todo-${todo.id}`}
                    checked={todo.completed}
                    onCheckedChange={() => toggleTodo(todo.id)}
                    className="border-blue-400 text-blue-600"
                  />
                  <label
                    htmlFor={`todo-${todo.id}`}
                    className={`cursor-pointer ${todo.completed ? "line-through text-blue-300" : "text-blue-800"}`}
                  >
                    {todo.text}
                  </label>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteTodo(todo.id)}
                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                >
                  Delete
                </Button>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}
